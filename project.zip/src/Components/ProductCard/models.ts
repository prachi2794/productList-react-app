export interface Item {
    id: string;
    bodyType: string;
    modelName: string;
    modelType: string;
    imageUrl: string;
}